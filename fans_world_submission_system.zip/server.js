// Fans World submission server
// Set ADMIN_EMAIL in your environment before starting.
// This demo sends ordinary membership submissions to that email.
// It does NOT accept government-ID documents.
const express = require("express");
const multer = require("multer");
const nodemailer = require("nodemailer");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_EMAIL = process.env.ADMIN_EMAIL;
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 8 * 1024 * 1024 },
  fileFilter: (req, file, cb) =>
    file.mimetype.startsWith("image/") ? cb(null, true) : cb(new Error("Images only"))
});

if (!ADMIN_EMAIL) console.warn("ADMIN_EMAIL is not set. Email delivery will not work.");

app.use(express.json({limit:"50kb"}));
app.use(express.static(path.join(__dirname, "public")));

function mailer() {
  // Configure SMTP credentials in environment variables.
  return nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT || 587),
    secure: process.env.SMTP_SECURE === "true",
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
  });
}

app.post("/api/submissions", async (req,res) => {
  const {name,email,tier,country} = req.body || {};
  if (!name || !email || !tier) return res.status(400).json({error:"Name, email and package are required."});
  try {
    await mailer().sendMail({
      from: process.env.SMTP_FROM || process.env.SMTP_USER,
      to: ADMIN_EMAIL,
      replyTo: email,
      subject: `Fans World membership request — ${tier}`,
      text: `New membership request\n\nName: ${name}\nEmail: ${email}\nPackage: ${tier}\nCountry/Region: ${country || "(not provided)"}`
    });
    res.json({ok:true});
  } catch(e) {
    console.error(e);
    res.status(500).json({error:"Mail delivery failed."});
  }
});

app.post("/api/selfie", upload.single("photo"), async (req,res) => {
  if (!req.file) return res.status(400).json({error:"No image supplied."});
  // Email the ordinary profile photo as an attachment. Do not use this endpoint for IDs.
  try {
    await mailer().sendMail({
      from: process.env.SMTP_FROM || process.env.SMTP_USER,
      to: ADMIN_EMAIL,
      subject: "Fans World member photo submission",
      text: "A member submitted a profile photo through the Fans World site.",
      attachments: [{filename:req.file.originalname || "member-photo.jpg", content:req.file.buffer, contentType:req.file.mimetype}]
    });
    res.json({ok:true});
  } catch(e) {
    console.error(e);
    res.status(500).json({error:"Mail delivery failed."});
  }
});

app.get("*", (req,res) => res.sendFile(path.join(__dirname,"public","index.html")));

app.listen(PORT, () => console.log(`Fans World running on port ${PORT}`));
