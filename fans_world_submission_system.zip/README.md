# Fans World submission system

This package turns the static Fans World page into a server-backed form.

## What it receives
- Membership/contact details: name, email, selected package, country/region.
- Optional member profile photo.

## What it intentionally does not receive
- Passport scans/numbers
- Driver's-license scans/numbers
- Banking passwords, PINs, OTPs, or full card credentials

## Setup
1. Install Node.js.
2. Run `npm install`.
3. Copy `.env.example` to `.env` and set ADMIN_EMAIL plus SMTP settings.
4. Start with `npm start`.
5. Open `http://localhost:3000`.

For public use, deploy the server on a HTTPS host and use a reputable transactional email provider. Do not expose SMTP credentials in frontend code.
